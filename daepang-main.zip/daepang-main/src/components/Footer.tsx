// [Footer] 사이트 하단 공통 푸터
import React from"react";export default function Footer(){return(<footer className="section"><div className="container" style={{color:"var(--muted)",textAlign:"center"}}>© 2025 대팡 프로젝트</div></footer>)}
